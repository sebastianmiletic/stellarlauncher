#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 0) out vec3 viewRay;

void main() {
    vec4 view = ModelViewMat * vec4(Position, 1.0);
    viewRay = view.xyz;
    gl_Position = ProjMat * view;
}
